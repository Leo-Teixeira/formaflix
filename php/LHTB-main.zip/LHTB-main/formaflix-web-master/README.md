# Formaflix

## Initialiser la base de données

```shell
php index.php db:migrate
```


---

Ce projet est réalisé à des fins pédagogiques. [Document associé disponible ici](https://cours.brosseau.ovh/tp/php/mvc/tp1.html)
