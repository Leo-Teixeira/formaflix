<div>
    <div class="cover cover-gradient">
        <h1>Votre plateforme de formation</h1>
        <h3>En 1-clic, partout, tout le temps…</h3>
    </div>
    <div class="bg-dark home-bottom">
        <h3>Prêt ? 3, 2, 1…</h3>
        <a href="./formations" class="btn btn-xlarge btn-danger mt-3">Découvrez nos formations →</a>
    </div>
</div>