<div class="container mt-5">
    <div class="row">
        <div class="card">
            <div class="card-body">
                <h3>FormaFlix</h3>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias, commodi delectus eaque eos esse ex illum laboriosam laborum modi, molestias necessitatibus non provident quidem quis repellat soluta tempore, veritatis vitae.
                </p>

                <ul>
                    <li>HTML + CSS 3</li>
                    <li>PHP 8</li>
                    <li>Boostrap 5</li>
                </ul>
            </div>
        </div>
    </div>
</div>
